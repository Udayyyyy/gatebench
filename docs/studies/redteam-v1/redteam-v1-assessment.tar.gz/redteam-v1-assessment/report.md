# Assessment of frozen independent model-assisted controls

Literal freeze: `df3feb4bf3aefe41a818c540db278e18a67b01121ec80068f794dede5aba5315`. 332 trajectories across 12 parameter-holdout tasks: 152 valid alternatives and 180 invalid controls.

Expected labels come from the pre-grading freeze. No grader determines or changes a label.

| Grader | Invalid accepted | Valid rejected |
|---|---:|---:|
| transcript | 0 / 180 | 152 / 152 |
| goal | 136 / 180 | 0 / 152 |
| final_state | 88 / 180 | 0 / 152 |
| exact_trace | 0 / 180 | 152 / 152 |
| hardened | 0 / 180 | 0 / 152 |
| no_history | 88 / 180 | 0 / 152 |
| no_frame | 12 / 180 | 0 / 152 |
| no_replay | 0 / 180 | 0 / 152 |

The hardened verifier has no observed frozen-label disagreement. No bypass was found and no verifier fix is justified by this freeze.

All 628 grader/trajectory mismatches retain their frozen labels after model-assisted public-policy review and concrete witness rechecking. Rejection reasons and observed acceptance are preserved per grader in rows.json.

## Bounded verifier timing

Five measured calls per fixed episode and grader follow one unmeasured warm-up. Only grade() is inside perf_counter_ns; environment construction, action execution, label checks and serialization are excluded. Samples are interleaved by episode/grader, not randomized. These are local microbenchmarks, not deployment latency.

| Grader | Median μs | p95 μs | Maximum μs | Samples |
|---|---:|---:|---:|---:|
| transcript | 0.46 | 0.71 | 1.04 | 1660 |
| goal | 12.71 | 14.25 | 51.54 | 1660 |
| final_state | 69.83 | 84.46 | 128.54 | 1660 |
| exact_trace | 2.54 | 2.92 | 44.71 | 1660 |
| hardened | 844.71 | 1158.48 | 2212.04 | 1660 |
| no_history | 585.77 | 843.40 | 1407.71 | 1660 |
| no_frame | 837.38 | 1145.42 | 2348.75 | 1660 |
| no_replay | 309.17 | 446.04 | 904.21 | 1660 |

Raw measured calls are in timings.json. Machine/Python metadata is in summary.json.

## Original implementation

Original grading/backend sources and dependencies are byte-identical: observed counts also describe that implementation.

## Limits

- Separately developed model-assisted scripted controls, not external human adjudication or autonomous model attacks.
- The 12 tasks are a parameter holdout using the same templates as development; they are not a novel-template holdout.
- The designer saw README headline results and broad examples, but no grader/corpus implementation before freezing.
- Frozen final answers do not contain 'completed'; transcript rejects every case for that fixed wording, so its result is confounded.
- Timing is a bounded local Python microbenchmark on fixed short episodes, excluding backend creation; it is not deployment latency.
- No executable evidence-corruption attacks are included here; replay ablation agreement does not make replay unnecessary.
- Zero mismatches on this finite curated freeze do not establish verifier soundness or real-agent failure rates.
